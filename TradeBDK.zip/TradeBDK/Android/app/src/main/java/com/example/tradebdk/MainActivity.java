package com.example.tradebdk;

import static android.os.Build.*;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @RequiresApi(api = VERSION_CODES.O)
    public void toCipher(View view) {
        // Get the reference to the EditText view in the layout
        EditText inputField =findViewById(R.id.Msgbox);
        EditText Bird =findViewById(R.id.C1);
        EditText Dolphin =findViewById(R.id.C2);
        EditText Kangaroo =findViewById(R.id.C3);

        try{
            // Get the text entered by the user
            String msg = inputField.getText().toString();
            int band, dand, kand;
            band = Integer.parseInt(Bird.getText().toString());
            dand = Integer.parseInt(Dolphin.getText().toString());
            kand = Integer.parseInt(Kangaroo.getText().toString());

            //my code
            String s = msg;

            int l = s.length();
            if(l<=2){ throw new Exception("Unknown");}
            String dolph = "";
            String kang = "";
            String bird = "";

            for (int i = 0; i < l; i += 3) {
                dolph = dolph.concat(String.valueOf(s.charAt(i)));
                s = s.substring(0, i) + (char) 231 + s.substring(i + 1);
            }

            int k = l - 1;
            if (s.charAt(k) == (char) 231) {
                k--;
            }
            for (int i = k; i >= 0; i -= 3) {
                kang = kang.concat(String.valueOf(s.charAt(i)));
                s = s.substring(0, i) + (char) 231 + s.substring(i + 1);
            }
            for (int i = 0; i < l; i++) {
                if (s.charAt(i) != (char) 231) {
                    bird = bird.concat(String.valueOf(s.charAt(i)));
                    s = s.substring(0, i) + (char) 231 + s.substring(i + 1);
                }
            }

            int bir, dol, kan;

            bir = band;
            dol = dand;
            kan = kand;
            String BDK = "";
            if (bir == dol && dol == kan) {
                BDK = bird + dolph + kang;
            } else if (bir > dol && dol > kan) {
                BDK = bird + dolph + kang;
            } else if (bir > kan && kan > dol) {
                BDK = bird + kang + dolph;
            } else if (dol > bir && bir > kan) {
                BDK = dolph + bird + kang;
            } else if (dol > kan && kan > bir) {
                BDK = dolph + kang + bird;
            } else if (kan > bir && bir > dol) {
                BDK = kang + bird + dolph;
            } else if (kan > dol && dol > bir) {
                BDK = kang + dolph + bird;
            }

            //BDK


            // EditText myEditText = findViewById(R.id.Msgbox); // Get the EditText by its ID
            String myString = BDK; // The string value to display
            inputField.setText(myString); // Set the text of the EditText to the string value
            inputField.setSelection(0);

            ClipboardManager clipboardManager=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData=ClipData.newPlainText("text",myString);
            clipboardManager.setPrimaryClip(clipData);
            Toast.makeText(MainActivity.this,"Copied to clipboard",Toast.LENGTH_SHORT).show();





        }
        catch (Exception e)
        {
            Toast.makeText(MainActivity.this,"Invalid Input",Toast.LENGTH_SHORT).show();
            inputField.setText("");

        }
        finally {
            Bird.setText("");
            Dolphin.setText("");
            Kangaroo.setText("");
        }



    }
    public void toPlain(View view) {
        //Get the reference to the EditText view in the layout
        EditText inputField =findViewById(R.id.Msgbox);
        EditText Bird=findViewById(R.id.C1);
        EditText Dolphin=findViewById(R.id.C2);
        EditText Kangaroo=findViewById(R.id.C3);


        try {
            // Get the text entered by the user
            String msg = inputField.getText().toString();
            int band, dand, kand;
            band = Integer.parseInt(Bird.getText().toString());
            dand = Integer.parseInt(Dolphin.getText().toString());
            kand = Integer.parseInt(Kangaroo.getText().toString());


            ///mycode

            String cip =new String(msg);
            //char[] cpa = msg.toCharArray();


            int len = msg.length();
            int bl = 0, dl = 0, kl = 0, sum;

            for (int i = 0; i < len; i++) {
                sum = dl + kl + bl;
                if (sum == len)
                    break;
                dl++;

                sum = dl + kl + bl;
                if (sum == len)
                    break;
                kl++;

                sum = dl + kl + bl;
                if (sum == len)
                    break;
                bl++;
            }

            String ed = "", ek = "", eb = "";
            int bc, dc, kc;

            bc = band;
            dc = dand;
            kc = kand;

            if ((bc > dc && dc > kc) || (bc == kc && kc == dc)) {
                int i, j, k;
                for (i = 0; i < bl; i++)
                    eb = eb.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < bl + dl; j++)
                    ed = ed.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++)
                    ek = ek.concat(String.valueOf(cip.charAt(k)));
            } else if (bc > kc && kc > dc) {
                int i, j, k;
                for (i = 0; i < bl; i++)
                    eb = eb.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < bl + kl; j++)
                    ek = ek.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++)
                    ed = ed.concat(String.valueOf(cip.charAt(k)));
            } else if (dc > bc && bc > kc) {
                int i, j, k;
                for (i = 0; i < dl; i++)
                    ed = ed.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < bl + dl; j++)
                    eb = eb.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++)
                    ek = ek.concat(String.valueOf(cip.charAt(k)));
            } else if (dc > kc && kc > bc) {
                int i, j, k;
                for (i = 0; i < dl; i++)
                    ed = ed.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < kl + dl; j++)
                    ek = ek.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++)
                    eb = eb.concat(String.valueOf(cip.charAt(k)));
            } else if (kc > bc && bc > dc) {
                int i, j, k;
                for (i = 0; i < kl; i++)
                    ek = ek.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < bl + kl; j++)
                    eb = eb.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++)
                    ed = ed.concat(String.valueOf(cip.charAt(k)));
            } else if (kc > dc && dc > bc) {
                int i, j, k;
                for (i = 0; i < kl; i++) ek = ek.concat(String.valueOf(cip.charAt(i)));
                for (j = i; j < kl + dl; j++) ed = ed.concat(String.valueOf(cip.charAt(j)));
                for (k = j; k < bl + dl + kl; k++) eb = eb.concat(String.valueOf(cip.charAt(k)));
            }

            int clen = eb.length() + ed.length() + ek.length();
            char[] CIP = new char[clen];
            for (int i = 0; i < clen; i++) {
                CIP[i] = (char) 231;
            }

            int dbigin = 0;
            int kbigin = clen - 1;
            for (int i = 0; i < clen; i += 3) {
                CIP[i] = ed.charAt(dbigin);
                dbigin++;
            }
            if (!(CIP[kbigin] == (char) 231)) kbigin--;

            int ks = 0;
            for (int i = kbigin; i >= 0; i -= 3) {
                CIP[i] = ek.charAt(ks);
                ks++;
            }

            int bbigin = 0;
            for (int i = 0; i < clen; i++) {
                if (CIP[i] == (char) 231) {
                    CIP[i] = eb.charAt(bbigin);
                    bbigin++;
                }
            }

            String cstr = "";
            for (int i = 0; i < clen; i++) {
                cstr = cstr.concat(String.valueOf(CIP[i]));
            }
            //cstr

            String myString = cstr; // The string value to display
            inputField.setText(myString); // Set the text of the EditText to the string value
            inputField.setSelection(0);


           /* ClipboardManager clipboardManager=(ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData=ClipData.newPlainText("text",myString);
            clipboardManager.setPrimaryClip(clipData);
            Toast.makeText(MainActivity.this,"Copied to clipboard",Toast.LENGTH_SHORT).show();
            */
        }
        catch (Exception e)
        {
            Toast.makeText(MainActivity.this,"Invalid Input",Toast.LENGTH_SHORT).show();
            inputField.setText("");
        }
        finally {
            Bird.setText("");
            Dolphin.setText("");
            Kangaroo.setText("");
        }

    }
    public void toDeveloper(View view){
        Toast.makeText(MainActivity.this,"TAXINATOR",Toast.LENGTH_SHORT).show();
    }
}
