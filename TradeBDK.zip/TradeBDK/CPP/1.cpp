#include<iostream>
using namespace std;
int main()
{
	char s[10000]={0};
	cout<<"Enter Message:::"<<endl;//eos lmtmwldoyoecwe lhlureo   r
	cin.getline(s,10000);
	int z=0;
	int l=0;
	while(s[z]!='\0')
	{
		l++;
		z++;
	}
	//cout<<c;
	string dolph="";
	string kang="";
	string bird="";
	
	for(int i=0;i<l;i+=3)
	
	{
		dolph+=s[i];
		s[i]=char(231);
	}
	
	int k=l-1;
	if(s[k]==char(231))
		k--;
	for(int i=k;i>=0;i-=3)
		{
		kang+=s[i];
		s[i]=char(231);;
		}
	for(int i=0;i<l;i++)
	{
		if(s[i]!=char(231))
		{
			bird+=s[i];
			s[i]=char(231);
		}
	}
	
	int bir,dol,kan;
	//cout<<endl<<"ENTER B-D-K COSTs"<<endl;
	cin>>bir>>dol>>kan;
	string BDK="";
	if(bir==dol and dol==kan)
		BDK=bird+dolph+kang;
	else if(bir>dol and dol>kan) 
		BDK=bird+dolph+kang;
	else if(bir>kan and kan>dol)
		BDK=bird+kang+dolph;
	else if(dol>bir and bir>kan)
		BDK=dolph+bird+kang;
	else if(dol>kan and kan>bir)
		BDK=dolph+kang+bird;
	else if(kan>bir and bir>dol)
		BDK=kang+bird+dolph;
	else if(kan>dol and dol>bir)
		BDK=kang+dolph+bird;
	else{}
	cout<<"YOUR CIPHER			:"<<BDK<<endl;
return 0;
}
