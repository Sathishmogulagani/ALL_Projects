	//DECRYPTION
	#include<iostream>
	using namespace std;
	int main()
	{
	cout<<"enter cypher:::"<<endl;
		
	char C[10000]={0};
	cin.getline(C,10000);

	int len=0;
	int z=0;
	while(C[z]!='\0')
	{
		len++;
		z++;
	}
	int bl=0;
	int dl=0;
	int kl=0;
	int sum=0;
	
		for(int i=0;i<len;i++)
	{
		sum=dl+kl+bl;
		if(sum==len) break;
		dl++;
		
		sum=dl+kl+bl;
		if(sum==len) break;
		kl++;
		
		sum=dl+kl+bl;
		if(sum==len) break;
		bl++;	
	}
	//cout<<dl<<kl<<bl<<endl;

	string ed="";
	string ek="";
	string eb="";
			
	int bc,dc,kc;
	//cout<<endl<<"ENTER B-D-K COSTs"<<endl;
	cin>>bc>>dc>>kc;
	//b
	if((bc>dc and dc>kc) or (bc==kc and kc==dc)) 
	{
		int i=0;
		int j=0;
		int k=0;
		for(i=0;i<bl;i++) eb+=C[i];//cout<<i<<endl;
		for(j=i;j<bl+dl;j++) ed+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) ek+=C[k];//cout<<k<<endl;
	}
	else if(bc>kc and kc>dc)  
	{
		int i=0;
		int j=0;
		int k=0;
		for(i=0;i<bl;i++) eb+=C[i];//cout<<i<<endl;
		for(j=i;j<bl+kl;j++) ek+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) ed+=C[k];//cout<<k<<endl;
	}
	//d
	else if(dc>bc and bc>kc)
	{
		int i=0;
		int j=0;
		int k=0;
		for(i=0;i<dl;i++) ed+=C[i];//cout<<i<<endl;
		for(j=i;j<bl+dl;j++) eb+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) ek+=C[k];//cout<<k<<endl;
	}
	else if(dc>kc and kc>bc) 
	{
		int i=0;
		int j=0;
		int k=0;
		for(i=0;i<dl;i++) ed+=C[i];//cout<<i<<endl;
		for(j=i;j<kl+dl;j++) ek+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) eb+=C[k];//cout<<k<<endl;
	}
	//k
	else if(kc>bc and bc>dc)
	{
		int i=0;
		int j=0;
		int k=0;
		for(i=0;i<kl;i++) ek+=C[i];//cout<<i<<endl;
		for(j=i;j<bl+kl;j++) eb+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) ed+=C[k];//cout<<k<<endl
	}
	else if(kc>dc and dc>bc)
	{
				int i=0;
		int j=0;
		int k=0;
		for(i=0;i<kl;i++) ek+=C[i];//cout<<i<<endl;
		for(j=i;j<kl+dl;j++) ed+=C[j];//cout<<j<<endl;
		for(k=j;k<bl+dl+kl;k++) eb+=C[k];//cout<<k<<endl;
	}
	else{
		cout<<"none";
	}	
	int clen=eb.length()+ed.length()+ek.length();
	//cout<<clen<<endl;
	char CIP[clen];
	for(int i=0;i<clen;i++){
		CIP[i]=char(231);}
	int dbigin=0;
	int kbigin=clen-1;
	for(int i=0;i<clen;i+=3)
	{
		CIP[i]=ed[dbigin];
		dbigin++;
	}
	if(!(CIP[kbigin]==char(231))) kbigin--;
	
	int ks=0;
	for(int i=kbigin;i>=0;i-=3) 
	{
		CIP[i]=ek[ks];
		ks++;
	}
	int bbigin=0;
	for(int i=0;i<clen;i++)
	{
		if(CIP[i]==char(231))
		{
			CIP[i]=eb[bbigin];
			bbigin++;
		}
	}
	string cstr="";
	for(int i=0;i<clen;i++) 
	{
	cstr+=CIP[i];
	}
	cout<<"YOUR PLAIN BACK:		"<<cstr<<endl;
	
	return 0;
}
