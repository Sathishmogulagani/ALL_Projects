--ctrl+shift+p-->palet
--ctrl+shift+Q-->to execute cmd
-- CREATE TABLE "BooksRack" (
-- 	"ISBN"	TEXT,
-- 	"Name"	TEXT,
-- 	"Author"	TEXT,
-- 	"Mail"	TEXT,
-- 	"Quantity"	INTEGER,
-- 	PRIMARY KEY("ISBN")
-- );
-- CREATE TABLE "issuedBooksData" (
-- 	"BookId"	TEXT,
-- 	"UserId"	TEXT,
-- 	"Phone"	TEXT,
-- 	"Copiesneed"	INTEGER,
-- 	"Dateofissue"	TEXT,
-- 	"DateofReturn"	TEXT
-- );
-- select * from issuedBooksData;
select * from BooksRack;

--insert into BooksRack values('101','The Magical Art of Hypnotism','Shreya Sehgal','ShrSehgal@gmail.com',12);
-- insert into BooksRack values('102','13 Tales of terror','Gaurav Modi','GauravModi25@gmail.com',8);
-- insert into BooksRack values('103','Screw it ,lets do it','Richard Branson','RichardBson91@gmail.com',10);
-- insert into BooksRack values('104','The Art of War','SUN TZU','SUNTUZ714@gmail.com',10);
-- insert into BooksRack values('105','Lifes Amazing Secrets','Guru Gopal Das','GuruDas768@gmail.com',15);
-- insert into BooksRack values('106','The Psychology of Money','Morgan Housel','MorganHousel@gmail.com',12);

-- delete from BooksRack where ISBN='101';